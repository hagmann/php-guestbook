# Changelog

## Version 1.0 (November 19, 2015)

Initial release.
