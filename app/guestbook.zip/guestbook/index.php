<?php include_once('head.php'); ?>

<div class="grid-x grid-padding-x">
    <div class="small-12 cell">
        <div class="slick-slider">
            <div>
                <img src="img/pexels-photo-640781.jpg" alt="">
            </div>
            <div>
                <img src="img/pexels-photo-258136.jpg" alt="Landschaft">

            </div>
            <div>
                <img src="img/pexels-photo-640781.jpg" alt="Landschaft">

            </div>
        </div>
    </div>
    <div class="small-12 medium-6 cell">
         <figure class="box">
            <div class="image-wrapper">
                <img src="img/pexels-photo-221341.jpg" alt="Landschaft">
            </div>
            <figcaption>
                <h2>Lorem ipsum dolor sit amet, consetetur sadipscing elitr</h2>
                <p><strong>Sed diam voluptua</strong>. At vero eos et accusam et justo duo dolores et ea rebum. Stet
                    clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor
                    sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et
                    dolore magna aliquyam erat, sed diam voluptua.</p>
            </figcaption>
        </figure>
    </div>
    <div class="small-12 medium-6 cell">
        <figure class="box">
            <div class="image-wrapper">
                <img src="img/pexels-photo-258136.jpg" alt="Landschaft">
            </div>
            <figcaption>
                <h2>Lorem ipsum dolor sit amet, consetetur sadipscing elitr</h2>
                <p><strong>Sed diam voluptua</strong>. At vero eos et accusam et justo duo dolores et ea rebum. Stet
                    clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor
                    sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et
                    dolore magna aliquyam erat, sed diam voluptua.</p>
            </figcaption>
        </figure>
    </div>
    <div class="small-12 medium-6 cell">
         <figure class="box">
            <div class="image-wrapper">
                <img src="img/pexels-photo-640781.jpg" alt="Landschaft">
            </div>
            <figcaption>
                <h2>Lorem ipsum dolor sit amet, consetetur sadipscing elitr</h2>
                <p><strong>Sed diam voluptua</strong>. At vero eos et accusam et justo duo dolores et ea rebum. Stet
                    clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor
                    sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et
                    dolore magna aliquyam erat, sed diam voluptua.</p>
            </figcaption>
        </figure>
    </div>
    <div class="small-12 medium-6 cell">
         <figure class="box">
            <div class="image-wrapper">
                <img src="img/pexels-photo-221341.jpg" alt="Landschaft">
            </div>
            <figcaption>
                <h2>Lorem ipsum dolor sit amet, consetetur sadipscing elitr</h2>
                <p><strong>Sed diam voluptua</strong>. At vero eos et accusam et justo duo dolores et ea rebum. Stet
                    clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor
                    sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et
                    dolore magna aliquyam erat, sed diam voluptua.</p>
            </figcaption>
        </figure>
    </div>
</div>

<?php include_once('footer.php'); ?>
