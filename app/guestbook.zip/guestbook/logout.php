<?php

session_destroy();

echo '<meta http-equiv=REFRESH CONTENT=0;url=index.php>';
