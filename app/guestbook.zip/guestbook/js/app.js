$(document).foundation();

$('.slick-slider').slick({
        dots: true
    }
);
